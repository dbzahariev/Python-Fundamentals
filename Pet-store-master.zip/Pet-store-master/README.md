# Pet-store
The aim of this small project is to help students at Software university. The students have knowledge of lists, dictionaries, files, 
classes and objects and also basic principles of OOP. It includes also flask, urls handilng, html templates, rendering and css.
